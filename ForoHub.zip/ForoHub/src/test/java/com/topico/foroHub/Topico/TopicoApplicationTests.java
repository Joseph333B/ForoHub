package com.topico.foroHub.Topico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
