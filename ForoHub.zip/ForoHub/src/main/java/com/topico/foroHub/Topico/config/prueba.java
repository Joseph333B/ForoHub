package com.topico.foroHub.Topico.config;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class prueba {

    public static void main(String[] args) {
        String rawPassword = "33333";
        String hashed = new BCryptPasswordEncoder().encode(rawPassword);
        System.out.println("Contraseña encriptada: " + hashed);
    }
}
