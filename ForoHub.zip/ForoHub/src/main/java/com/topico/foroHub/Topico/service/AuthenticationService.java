package com.topico.foroHub.Topico.service;

import com.topico.foroHub.Topico.inicio.Usuario;
import com.topico.foroHub.Topico.repository.UsuarioRepository;
import com.topico.foroHub.Topico.dto.LoginDTO;
import com.topico.foroHub.Topico.dto.JwtResponseDTO;
import com.topico.foroHub.Topico.security.JwtUtil;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {

    private final AuthenticationManager authManager;
    private final JwtUtil jwtUtil;
    private final UsuarioRepository usuarioRepo;

    public AuthenticationService(AuthenticationManager authManager, JwtUtil jwtUtil, UsuarioRepository usuarioRepo) {
        this.authManager = authManager;
        this.jwtUtil = jwtUtil;
        this.usuarioRepo = usuarioRepo;
    }

    public JwtResponseDTO login(LoginDTO loginDTO) {
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginDTO.correoElectronico(),
                        loginDTO.contrasena()
                )
        );

        String jwt = jwtUtil.generateToken(loginDTO.correoElectronico());
        return new JwtResponseDTO(jwt);
    }
}