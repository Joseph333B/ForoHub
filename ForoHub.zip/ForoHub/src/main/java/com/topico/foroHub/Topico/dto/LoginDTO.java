package com.topico.foroHub.Topico.dto;

public record LoginDTO(String correoElectronico, String contrasena) {}