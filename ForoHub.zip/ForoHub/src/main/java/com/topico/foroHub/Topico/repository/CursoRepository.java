package com.topico.foroHub.Topico.repository;

import com.topico.foroHub.Topico.inicio.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

    public interface CursoRepository extends JpaRepository<Curso, Long> {
    }

