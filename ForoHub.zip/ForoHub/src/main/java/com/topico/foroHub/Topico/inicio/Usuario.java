package com.topico.foroHub.Topico.inicio;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    private String correoElectronico;

    private String contrasena;

    @ManyToOne
    @JoinColumn(name = "perfiles")
    private Perfil perfil;

    @ManyToMany(fetch = FetchType.EAGER)
    private List<Perfil> perfiles;
}