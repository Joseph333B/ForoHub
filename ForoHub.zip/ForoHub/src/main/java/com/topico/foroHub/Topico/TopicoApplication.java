package com.topico.foroHub.Topico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TopicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TopicoApplication.class, args);
	}

}
